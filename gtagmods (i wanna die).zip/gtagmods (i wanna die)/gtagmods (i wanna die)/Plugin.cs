﻿using UnityEngine;
using UnityEngine.UI;
using BepInEx;
using GorillaLocomotion;
using GorillaNetworking;

namespace r0siemiscmods
{
    [BepInPlugin("rosie.misc.mods", "shit", "1.0.0")]
    public partial class Plugin : BaseUnityPlugin
    {
        private float mArmLength = 0.5f;
        private float boost = 0.0f;

        // below float is declated to fix the slider 

        

        public void Start()
        {
            
        }

        public void Update()
        {
            GTPlayer instance = GTPlayer.Instance;

            instance.maxArmLength = mArmLength;
            instance.jumpMultiplier = boost;
        }

        public void OnGUI()
        {
            GUI.backgroundColor = new Color(0.5f, 0f, 0.5f);

            if (GUI.Button(new Rect(80, 40, 120, 20), "----- Pleb Sets -----"))
            {
                GTPlayer instance = GTPlayer.Instance;

                instance.maxArmLength = 9999f;
                instance.jumpMultiplier = 7.5f;
            }

            if (GUI.Button(new Rect(80, 10, 120, 20), "----- Cheater Sets -----"))
            {
                GTPlayer instance = GTPlayer.Instance;

                instance.maxArmLength = 9999f;
                instance.jumpMultiplier = 6.5f;
            }

            if (GUI.Button(new Rect(80, -20, 120, 20), "----- R0se Sets -----"))
            {
                GTPlayer instance = GTPlayer.Instance;

                instance.maxArmLength = 9999f;
                instance.jumpMultiplier = 6.9f;
            }

            // sliders here will be fixed next upd

            // float maxArmLengthVal = GUI.HorizontalSlider(new Rect(20, 0, 80, 20), mArmLength, 0.0f, 9999f);
        }
    }
}
